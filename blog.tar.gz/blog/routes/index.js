// 每个路由文件都需要引入express
var express = require('express');
// 实例化一个路由实例来捕获访问主页的GET请求
var router = express.Router();
// 引入配置文件
var config = require('../config/config.js');

// 引入mongoose
var mongoose = require('mongoose');
var Post = mongoose.model('Post');

// 一个文章总个数的中间件
router.all('*',function(req,res,next){
  Post.count(function(err,count){
    if(err){
      res.end("获取文章异常");
    }
    var pageCount = Math.ceil(count/config.pageRow);
    req.pageCount = pageCount;
  });
  next();
});

// 一个获取页码的中间件
router.param('id',function(req,res,next,id){
  req.pageId = id;
  next();
});
router.get('/page/:id',function(req,res){
  //获取分页内容
  var pageRow = config.pageRow;
  var pageId = req.pageId - 1;
  // 获取文章信息(指定升序)  
  Post.find({}).gt('id',pageId*pageRow).limit(pageRow).sort('id').exec(function(err,docs){
    if(err){
      req.flash('error',err);
      return res.redirect('/');
    }

    res.render('index', {
     pageCurrent:req.pageId,
     pageCount:req.pageCount,
     active:'home',
     title: '主页' ,
     user:req.session.user,
     posts:docs,
     success:req.flash('success').toString(),
     error:req.flash('error').toString()
    });

  });
});


/* GET home page. */
router.get('/', function(req, res, next) {
  // 这样当访问主页时，就会调用res.render('index',{title:'Express'})渲染view/index.ejs模板并显示在浏览器中
  // 分页
  pageRow = config.pageRow;
  
  // 获取文章信息(指定升序)  
  Post.find({}).limit(pageRow).sort('id').exec(function(err,docs){
  	if(err){
  		req.flash('error',err);
  		return res.redirect('/');
  	}

  	res.render('index', {
     pageCurrent:1,
     pageCount:req.pageCount,
     active:'home',
	   title: '主页' ,
	   user:req.session.user,
	   posts:docs,
	   success:req.flash('success').toString(),
	   error:req.flash('error').toString()
	  });

  });
  
});


// 导出这个路由并在app.js中通过require加载。
module.exports = router;
