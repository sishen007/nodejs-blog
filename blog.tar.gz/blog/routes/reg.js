var express = require('express');
var router = express.Router();

//引入flash模块
var flash = require('connect-flash');

//引入crypto模块，为密码加密
var crypto = require('crypto');

//引入数据库
var mongoose = require('mongoose');
var User = mongoose.model('User');

// 登录权限控制，即已登录的用户不可以访问该页面
router.get('/',function(req,res,next){
	if(req.session.user){
		req.flash('error','登录状态，不可以注册');
		return res.redirect('/');
	}
	next();
});


router.get('/',function(req,res){

	res.render('reg',{
		active:'reg',
		title:'注册',
		user:req.session.user,
		success:req.flash('success').toString(),
		error:req.flash('error').toString()
	});
});

router.post('/',function(req,res){
	var name = req.body.name;
	var password = req.body.password;
	var password_repeat = req.body.password_repeat;
	if(password!==password_repeat){
		req.flash('error','两次输入的密码不一致');
		return res.redirect('/reg');//返回注册页
	}
	// 生成密码的MD5值
	var md5 = crypto.createHash('md5');
	var password_crypt = md5.update(req.body.password).digest('hex');
	var user = new User({
		name:name,
		password:password_crypt,
		email:req.body.email		
	});
	User.find({name:name},function(err,doc){
		if(err){
			req.flash('error',err);
			return res.redirect('/');
			// res.end("chazhaofailed");
			// return ;
		}
		if(doc.length!=0){
			// return res.end("doc:"+JSON.stringify(doc));
			req.flash('error','用户已存在');
			return res.redirect('/reg');
		}		
		//如果用户不存在则新增
		user.save(function(err){
			if(err){
				req.flash('error',err);
				return res.redirect('/reg');
			}
			req.session.user = user;
			req.flash('success','注册成功');
			res.redirect('/');//注册成功返回首页
		});
	});
	
});

module.exports=router;