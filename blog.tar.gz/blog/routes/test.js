var express = require('express');
var router = express.Router();

router.get('/test',function(req,res){
	res.render('test',{name:'sishen007','city':'shanghai'});
});

module.exports=router;