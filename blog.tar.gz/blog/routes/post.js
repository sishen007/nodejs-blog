var express = require('express');
var router = express.Router();

// 加载时间格式化函数
var timeFormat = require('../common/timeFormat.js');

// 引入mongoose
var mongoose = require('mongoose');
var Post = mongoose.model('Post');


// 用户认证
router.get('/',function(req,res,next){
	if(!req.session.user){
		req.flash('error','请登录后再发表');
		return res.redirect('/');
	}

	next();
});


// 发表页展示
router.get('/',function(req,res){
	
	res.render('post',{
		active:'post',
		title:'发表',
		user:req.session.user,
		success:req.flash('success').toString(),
		error:req.flash('error').toString()
	});
});


// 发表文章
router.post('/',function(req,res){
	var title = req.body.title;
	var postinfo = req.body.post;
	var name = req.session.user.name;
	var time = timeFormat(1,1,1,1);
	var post = new Post({
		name:name,
		time:time,
		title:title,
		post:postinfo
	});
	//获取当前一共有多少文章
	Post.count(function(err,count){
		if(err){
			req.flash('error','新增文章失败');
			return res.redirect('/post');
		}			
		post.id=count+1;
		// 存储一篇文章
		post.save(function(err){
			if(err){
				req.flash('error',err);
				return res.redirect('/post');
			}
			req.flash('success','发表成功');
			return res.redirect('/');
		});
	});

	
});
module.exports=router;