var express = require('express');
var router = express.Router();

//引入crypto模块，为密码加密
var crypto = require('crypto');


// 引入mongoose 
var mongoose = require('mongoose');
var User = mongoose.model('User');

router.get('/',function(req,res,next){
	if(req.session.user){
		req.flash('error','您已登录');
		return res.redirect('/');
	}
	next();
});

router.get('/',function(req,res){
	res.render('login',{
		active:'login',
		title:'登录',
		user:req.session.user,
		success:req.flash('success').toString(),
		error:req.flash('error').toString()
	});
});

// 登录流程
router.post('/',function(req,res){
	var name = req.body.name;
	var md5 = crypto.createHash('md5');
	var password = md5.update(req.body.password).digest('hex');
	
	// 检查用户是否存在
	User.where({name:name}).findOne(function(err,doc){
		if(err){
			req.flash('error',err);
			return res.redirect('/login');
		}
		
		if(!doc){
			req.flash('error','用户不存在');
			return res.redirect('/login');
		}
		// 用户存在验证密码是否正确
		if(doc.password != password){
			req.flash('error','密码错误');
			return res.redirect('/login');
		}
		// 密码正确则登录
		req.session.user = doc;
		req.flash('success','登录成功');
		return res.redirect('/');

	});
});


module.exports=router;