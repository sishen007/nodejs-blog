//加载一些第三方模块
var express = require('express');
var path = require('path');
var favicon = require('serve-favicon');
var logger = require('morgan');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');

// 加载时间格式化函数
var timeFormat = require('./common/timeFormat.js');


// 生成express实例
var app = express();

// 引入数据库
var mongodb = require('./config/model.js');
var db = mongodb();

// 引入会话
var session = require('express-session');
var MongoStore = require('connect-mongo')(session);

app.use(session({
  resave:false,
  saveUninitialized:true,
  secret:'blog',//为了防止篡改cookie
  key:'blog',//cookie名称
  cookie:{maxAge:1000*60*60*24*30},//cookie有效期
  store:new MongoStore({//将会话信息存储到mongo数据库中，以免数据丢失
    db:'blog',
    host:'localhost',
    port:'27017'
  })
}));

// 引入routes文件夹下的index和users路由文件
var index = require('./routes/index');
var users = require('./routes/users');



// 设置存放视图文件的路径,及设置视图模板引擎为ejs
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

//引入flash模块
var flash = require('connect-flash');
app.use(flash());
// sishen007 设置程序运行环境是开发环境还是生产环境
// app.set('env','no');

// uncomment after placing your favicon in /public
//app.use(favicon(path.join(__dirname, 'public', 'favicon.ico')));
// 加载日志中间件
app.use(logger('dev'));
// 加载解析json的中间件
app.use(bodyParser.json());
// 加载解析urlencode请求的中间件
app.use(bodyParser.urlencoded({ extended: false }));
// 加载解析cookie的中间件
app.use(cookieParser());
// 设置public文件夹为存放静态文件的目录
// 这在view视图文件中引入的css，img，js路径有关
app.use(express.static(path.join(__dirname, 'public')));

// 路由控制器
app.use('/', index);
app.use('/users', users);
app.use('/login',require('./routes/login.js'));
app.use('/',require('./routes/logout.js'));
app.use('/post',require('./routes/post.js'));
app.use('/reg',require('./routes/reg.js'));

// 捕获404错误，并转发到错误处理器
app.use(function(req, res, next) {
  var err = new Error('Not Found');
  err.status = 404;
  next(err);
});

// 开发环境下的错误处理器，将错误信息渲染error模板并显示到浏览器中。
app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;  
  // res.end(req.app);
  // 此时req.app.get('env')为development
  // req.app 是对app的引用,只不过是在中间件里面的时候使用该形式
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});

// 导出app实例供其他模块调用
module.exports = app;
