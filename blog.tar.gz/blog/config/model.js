var mongoose = require('mongoose');
var mongooseConfig = require('./config.js');
module.exports=function(){	
	var db = mongoose.connect(mongooseConfig.mongodb);	
	// require('../moduels/blog.server.model.js');
	require('../moduels/user.server.model.js');
	return db;
}