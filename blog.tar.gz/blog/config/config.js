module.exports={
	mongodb:"mongodb://localhost/blog",
	pageRow:3,//每页显示的数量
};