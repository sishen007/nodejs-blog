var mongoose = require('mongoose');
// 用户
var UserSchema = mongoose.Schema({
	name:String,
	password:String,
	email:String
});
var User = mongoose.model('User',UserSchema);

// 文章
var PostSchema = mongoose.Schema({
	id:{
		type:Number,
		unique:true
	},
	name:String,
	time:String,
	title:String,
	post:String
});
var Post = mongoose.model('Post',PostSchema);