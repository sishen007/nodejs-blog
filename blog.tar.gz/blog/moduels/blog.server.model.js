var mongoose = require('mongoose');
var BlogSchema = mongoose.Schema({
	username:String,
	password:String,
	regTime:Date,
	loginTime:Date
});

var Blog = mongoose.model('Blog',BlogSchema);

// var blog = new Blog({
// 	username:'admin',
// 	password:'admin',
// 	regTime:Date().now,
// 	loginTime:Date().now
// });

