// $("li[role='presentation']").on('click',function(){
// 	$("li[role='presentation']").removeAttr("class");
// 	$(this).attr("class","active");
// });