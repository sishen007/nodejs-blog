module.exports=function(to_day,to_hour,to_minutes,to_second){
	var date = new Date();
	var year = date.getFullYear();
	var month = date.getMonth()+1;
	var day = date.getDate();
	var hour = date.getHours();
	var minutes = date.getMinutes();
	var second = date.getSeconds();
	if(to_second==1)
		return year+'年'+month+'月'+day+'日'+' '+hour+'时'+minutes+'分'+second+'秒';
	if(to_minutes==1)
		return year+'年'+month+'月'+day+'日'+' '+hour+'时'+minutes+'分';
	if(to_hour==1)
		return year+'年'+month+'月'+day+'日'+' '+hour+'时';
	if(to_day==1)
		return year+'年'+month+'月'+day+'日';
}